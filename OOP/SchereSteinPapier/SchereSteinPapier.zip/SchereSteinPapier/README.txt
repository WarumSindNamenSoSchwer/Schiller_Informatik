Im Flussdiagramme Ordner ist einmal die drawio datei die ein zum ausfüllendes Flussdiagramm beinhaltet und 
das Aufgabenblatt für die gesamte Schere-Stein-Papier (SSP) Aufgabe.

Der Code Ordner beinhaltet fürs Erste 3 mögliche Schwierigkeitsstufen mit immer weniger vollständigen Python-
code es geht von 0-leicht zu 2-schwer, 2 hat dazu noch eine extra Denkaufgabe zur erschließung der 
Einstiegspunkt-Funktion (entrypoint), da ich denke, dass diese doch sehr wichtig ist zu verstehen. Vorallem wenn
man später vielleicht in die Richtung IT geht, da dieser in anderen Sprachen wie C oder Java immer vorahnden ist.

Noch dazu hat der Code-Ordner einen Lösungs-Ordner mit den Lösungen und einen Pseudocode-Ordner für den von mir 
geschriebenen Pseudocode zu dem Spiel.
 